﻿
Partial Class image_sach_Default
    Inherits System.Web.UI.Page

End Class
